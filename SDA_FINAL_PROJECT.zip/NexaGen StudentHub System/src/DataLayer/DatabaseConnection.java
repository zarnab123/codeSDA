package DataLayer;

import java.sql.*;
import java.util.*;
import java.util.Date;

public class DatabaseConnection 
{

    public static Connection getConnection() 
    {
        Connection c = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");

            String url = "jdbc:mysql://localhost:3306/StudentDB"; 
            String username = "root";  
            String password = "Samiya.2003"; 

            c = DriverManager.getConnection(url, username, password);

        } 
        catch (ClassNotFoundException e) 
        {
            System.out.println("MySQL JDBC Driver not found.");
            e.printStackTrace();
        } 
        catch (SQLException e) 
        {
            System.out.println("Failed to make connection to the database.");
            e.printStackTrace();
        }
        return c; 
    }

    public static String fetchCourseMaterials(String courseName) 
    {
        String s = "Unable to connect to the database";
        Connection c = getConnection(); 

        if (c != null) 
        {
            try 
            {
                String query = "SELECT materials FROM CourseMaterials WHERE course_name = ?";
                PreparedStatement p = c.prepareStatement(query);
                p.setString(1, courseName); 
                ResultSet r = p.executeQuery();
                
                if (r.next()) 
                {
                    s = r.getString("materials"); 
                } 
                else 
                {
                    s = "Course materials not found for the given course name.";
                }
            } 
            catch (SQLException e) 
            {
                System.out.println("Database error while fetching course materials.");
                e.printStackTrace();
                s = "Database error.";
            } 
            finally 
            {
                try {
                    c.close();
                } 
                catch (SQLException e) {
                    System.out.println("Error closing database connection.");
                    e.printStackTrace();
                }
            }
        }
        return s;
    }

    public static Map<String, Date> getTasksFromDatabase() 
    {
        Map<String, Date> t = new HashMap<>();
        String s = "SELECT task_name, due_date FROM Deadline";  
        
        try (Connection conn = getConnection(); 
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(s)) 
        {

            while (rs.next()) 
            {
                String t_Name = rs.getString("task_name");
                Timestamp due_Date = rs.getTimestamp("due_date");
                t.put(t_Name, due_Date);  
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
        return t;
    }
    
    public static String fetchExamTimetable(String studentName) 
    {
        String s = "Timetable not found"; 
        Connection c = getConnection(); 

        if (c != null) 
        {
            try {
                String q1 = "SELECT timetable FROM ExamTimeTable WHERE student_name = ?";
                PreparedStatement p = c.prepareStatement(q1);
                p.setString(1, studentName);
                ResultSet rs = p.executeQuery();

                if (rs.next()) 
                {
                    s = rs.getString("timetable"); 
                } 
                else 
                {
                    s = "Timetable not found for the given student name.";
                }
            } 
            catch (SQLException e) 
            {
                System.out.println("Database error while fetching exam timetable.");
                e.printStackTrace();
                s = "Database error.";
            } 
            finally 
            {
                try 
                {
                    c.close(); 
                } 
                catch (SQLException e) 
                {
                    System.out.println("Error closing database connection.");
                    e.printStackTrace();
                }
            }
        }
        return s;
    }
}
