package BusinessLogic;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import DataLayer.DatabaseConnection;

public class Notification {

	private List<String> n;  //composition
	
    public Notification() 
    {
    	n = new ArrayList<>(); //create array list
    }

    public void addNotification(String notificationText) 
    {
        String s = "INSERT INTO Notifications (Text) VALUES (?)";

        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement pstmt = c.prepareStatement(s)) 
        {
            pstmt.setString(1, notificationText);
            pstmt.executeUpdate();
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
    }

    public List<String> getNotifications() 
    {
        List<String> n = new ArrayList<>();
        String s1 = "SELECT Text FROM Notifications ORDER BY id ASC";

        try (Connection c = DatabaseConnection.getConnection();
             Statement s = c.createStatement();
             ResultSet r = s.executeQuery(s1)) 
        {

            while (r.next()) 
            {
                n.add(r.getString("Text"));
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }

        return n;
    }
};

