package BusinessLogic;
import DataLayer.DatabaseConnection;

//Business layer
import java.text.SimpleDateFormat;
import java.util.*;

public class DeadlineReminder 
{
 private Map<String, Date> due_tasks;

 public DeadlineReminder()
 {
     due_tasks = DatabaseConnection.getTasksFromDatabase(); 
 }

 public String checkUpcoming_due_tasks() 
 {
     StringBuilder r = new StringBuilder();
     SimpleDateFormat date = new SimpleDateFormat("EEEE, yyyy-MM-dd HH:mm:ss");

     Calendar c1 = Calendar.getInstance(); 
     Calendar c2 = Calendar.getInstance();
     c2.add(Calendar.DAY_OF_YEAR, 7); 

     for (Map.Entry<String, Date> entry : due_tasks.entrySet()) 
     {
         Date d = entry.getValue();
         
         if (!d.before(c1.getTime()) && d.before(c2.getTime())) 
         {
             r.append("Reminder: ").append(entry.getKey())
              .append(" is due on: ")
              .append(date.format(d))
              .append("\n");
         }
     }

     return r.length() > 0 ? r.toString() : "No upcoming tasks!";
 }
}
