package BusinessLogic;
import DataLayer.DatabaseConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Venue 
{
    public String SearchVenue(String subj) 
    {
        String q1 = "SELECT VenueLocation FROM Venue WHERE SubjectName = ?"; 
        try (Connection c = DatabaseConnection.getConnection();  
             PreparedStatement s = c.prepareStatement(q1)) 
        {
            
            s.setString(1, subj);  
            try (ResultSet r = s.executeQuery()) 
            {
                if (r.next()) 
                {
                    return r.getString("VenueLocation"); 
                }
            }
        } 
        catch (SQLException e) 
        {
            e.printStackTrace();
        }
        return "Venue Not Found for this Subject";
    }
}
