package BusinessLogic;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import DataLayer.DatabaseConnection;

public class AttendanceRecord 
{
    public String getAttendance(String studentName) 
    {
        String q1= "SELECT AttendanceDate, Status FROM AttendanceRecords WHERE StudentName = ?";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement P_stm = c.prepareStatement(q1)) 
        {
            P_stm.setString(1, studentName);
            ResultSet r = P_stm.executeQuery();

            StringBuilder result = new StringBuilder();
            while (r.next()) 
            {
                String d = r.getDate("AttendanceDate").toString();
                String s = r.getString("Status");
                result.append("Date: ").append(d).append(", Status: ").append(s).append("\n");
            }
            return result.length() > 0 ? result.toString() : "Attendance record not found";
        } 
        catch (Exception e) 
        {
            e.printStackTrace();
            return "Error retrieving attendance record";
        }
    }
}
