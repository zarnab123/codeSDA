package BusinessLogic;
import DataLayer.DatabaseConnection;

public class CourseMaterials 
{
    public String getCourseMaterials(String courseName) 
    {
        return DatabaseConnection.fetchCourseMaterials(courseName);
    }
}
