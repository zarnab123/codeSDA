package BusinessLogic;
import DataLayer.DatabaseConnection;

public class ExamTimetable 
{
    private DatabaseConnection DC;
    public ExamTimetable() 
    {
        DC = new DatabaseConnection();
    }

    public String getTimetable(String studentName) 
    {
        String tt = DatabaseConnection.fetchExamTimetable(studentName);
        return tt; 
    }
}
