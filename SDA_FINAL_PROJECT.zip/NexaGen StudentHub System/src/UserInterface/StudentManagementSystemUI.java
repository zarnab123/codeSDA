package UserInterface;

import javax.swing.*;
import java.awt.*;

public class StudentManagementSystemUI extends JFrame 
{
    private JButton b1;
    private JButton b2;
    private JButton b3;
    private JButton b4;
    private JButton b5;
    private JButton b6;

    public StudentManagementSystemUI() 
    {
        setTitle("Student Management System");
        setSize(900, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null); 

        JPanel bgPanel = new JPanel() 
        {
            private Image bgImage = new ImageIcon("C:\\Users\\user\\OneDrive\\Desktop\\bg 1.jpg").getImage();
            @Override
            protected void paintComponent(Graphics g) 
            {
                super.paintComponent(g);
                g.drawImage(bgImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        bgPanel.setLayout(new BorderLayout());

        JPanel hPanel = new JPanel();
        hPanel.setLayout(new BorderLayout());
        hPanel.setOpaque(false);

        JLabel hLabel = new JLabel("Student Management System");
        hLabel.setForeground(Color.WHITE);
        hLabel.setHorizontalAlignment(SwingConstants.CENTER);
        hLabel.setFont(new Font("Georgia", Font.BOLD, 30));

        JPanel hBox = new JPanel(new BorderLayout());
        hBox.add(hLabel, BorderLayout.CENTER);
        hBox.setBackground(new Color(135, 206, 235));
        hBox.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        hPanel.add(hBox, BorderLayout.NORTH);

        JPanel bPanel = new JPanel();
        bPanel.setLayout(new GridLayout(3, 2, 20, 20)); 
        bPanel.setOpaque(false);
        bPanel.setBorder(BorderFactory.createEmptyBorder(50, 150, 50, 150));

        b1 = createButton("Attendance Record");
        b2 = createButton("Course Material");
        b3 = createButton("Deadline Reminder");
        b4 = createButton("Exam Timetable");
        b5 = createButton("Notification Management");
        b6 = createButton("Venue Management");

        bPanel.add(b1);
        bPanel.add(b2);
        bPanel.add(b3);
        bPanel.add(b4);
        bPanel.add(b5);
        bPanel.add(b6);
        
        b4.addActionListener(e -> {
            new ExamTimetableUI();
            dispose();
        });

        b6.addActionListener(e -> {
            new VenueUI();
            dispose();
        });

        b5.addActionListener(e -> {
            new NotificationUI();
            dispose();
        });

        b3.addActionListener(e -> {
            new DeadlineReminderUI();
            dispose();
        });

        b1.addActionListener(e -> {
            new AttendanceRecordUI();
            dispose();
        });

        b2.addActionListener(e -> {
            new CourseMaterialsUI();
            dispose();
        });

        bgPanel.add(hPanel, BorderLayout.NORTH);
        bgPanel.add(bPanel, BorderLayout.CENTER);

        setContentPane(bgPanel);
        setVisible(true);
    }

    private JButton createButton(String text) 
    {
        JButton b = new JButton(text);
        b.setFont(new Font("Georgia", Font.BOLD, 18));
        b.setBackground(new Color(255, 255, 255, 200)); 
        b.setForeground(Color.BLACK);
        b.setFocusPainted(false);
        b.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        b.setPreferredSize(new Dimension(200, 50));
        return b;
    }

}

