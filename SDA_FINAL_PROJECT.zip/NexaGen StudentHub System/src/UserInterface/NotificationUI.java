package UserInterface;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import BusinessLogic.Notification;

public class NotificationUI extends JFrame {

    private JList<String> List_Of_Notifications;
    private JButton Button_back;
    private Notification n;

    public NotificationUI() 
    {
        n = new Notification();

        setTitle("Notification");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel bg_panel = new JPanel() 
        {
            private Image bg_image = new ImageIcon("C:\\Users\\user\\OneDrive\\Desktop\\bg 1.jpg").getImage();

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(bg_image, 0, 0, getWidth(), getHeight(), this);
            }
        };

        bg_panel.setLayout(new BorderLayout());
        JPanel h_Panel = new JPanel();
        h_Panel.setLayout(new BorderLayout());
        h_Panel.setOpaque(false);

        JLabel h_Label = new JLabel("Notification");
        h_Label.setForeground(Color.WHITE);
        h_Label.setHorizontalAlignment(SwingConstants.CENTER);
        h_Label.setFont(new Font("Georgia", Font.BOLD, 24));

        JPanel h_Box = new JPanel();
        h_Box.setLayout(new BorderLayout());
        h_Box.add(h_Label, BorderLayout.CENTER);
        h_Box.setBackground(new Color(135, 206, 235));
        h_Box.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        h_Panel.add(h_Box, BorderLayout.NORTH);

        Button_back = new JButton("BACK");
        Button_back.setBackground(null);
        Button_back.setFont(new Font("Georgia", Font.BOLD, 16));
        Button_back.setPreferredSize(new Dimension(120, 40));
        Button_back.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        Button_back.setFocusPainted(false);
        Button_back.setForeground(Color.BLACK);
        Button_back.addActionListener(e -> {
            new StudentManagementSystemUI();
            dispose(); 
        });

        JPanel f_Panel = new JPanel();
        f_Panel.setLayout(new FlowLayout(FlowLayout.LEFT));
        f_Panel.add(Button_back);
        f_Panel.setOpaque(false);

        JPanel n_Panel = new JPanel();
        n_Panel.setLayout(new BorderLayout());

        List_Of_Notifications = new JList<>();
        List_Of_Notifications.setCellRenderer(new Display_Bullets());

        n_Panel.add(new JScrollPane(List_Of_Notifications), BorderLayout.CENTER);
        n_Panel.setOpaque(false);

        bg_panel.add(h_Panel, BorderLayout.NORTH);
        bg_panel.add(n_Panel, BorderLayout.CENTER);
        bg_panel.add(f_Panel, BorderLayout.SOUTH);

        setContentPane(bg_panel);
        Notification_Update();
        setVisible(true);
    }

    private void Notification_Update() 
    {
        List<String> notify = n.getNotifications();

        if (notify.isEmpty()) 
        {
            List_Of_Notifications.setListData(new String[]{"No New Notifications"});
        } 
        else 
        {
            List_Of_Notifications.setListData(notify.toArray(new String[0]));
        }
    }

    class Display_Bullets extends DefaultListCellRenderer 
    {
        @Override
        public Component getListCellRendererComponent(JList<?> l, Object v, int i, boolean temp1, boolean temp2) {
            String b = "\u2022 " + v.toString();  // Unicode character for the bullets
            return super.getListCellRendererComponent(l, b, i, temp1, temp2);
        }
    }
}

