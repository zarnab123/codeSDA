package UserInterface;
import javax.swing.*;
import java.awt.*;
import BusinessLogic.DeadlineReminder;

public class DeadlineReminderUI extends JFrame 
{
    private JTextArea Text;
    private JButton Button_back;
    private DeadlineReminder DR;

    public DeadlineReminderUI() {
        DR = new DeadlineReminder();

        setTitle("Deadline Reminder");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel bgPanel = new JPanel() {
            private Image bg_image = new ImageIcon("C:\\Users\\user\\OneDrive\\Desktop\\bg 1.jpg").getImage();

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(bg_image, 0, 0, getWidth(), getHeight(), this);
            }
        };

        bgPanel.setLayout(new BorderLayout());

        JPanel hPanel = new JPanel();
        hPanel.setLayout(new BorderLayout());
        hPanel.setOpaque(false);

        JLabel hLabel = new JLabel("Deadline Reminder");
        hLabel.setForeground(Color.WHITE);
        hLabel.setHorizontalAlignment(SwingConstants.CENTER);
        hLabel.setFont(new Font("Georgia", Font.BOLD, 24));

        JPanel hBox = new JPanel();
        hBox.setLayout(new BorderLayout());
        hBox.add(hLabel, BorderLayout.CENTER);
        hBox.setBackground(new Color(135, 206, 235));
        hBox.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        hPanel.add(hBox, BorderLayout.NORTH);

        Text = new JTextArea(10, 30);
        Text.setEditable(false);
        Text.setFocusable(false);
        Text.setBackground(new Color(255, 255, 255, 230));
        Text.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        Text.setLineWrap(true);
        Text.setWrapStyleWord(true);
        Text.setFont(new Font("Arial", Font.PLAIN, 14));
        Text.setCaretColor(Color.BLACK);
        Text.setForeground(Color.BLACK);

        JScrollPane s = new JScrollPane(Text);
        s.getViewport().setOpaque(false);
        s.setBorder(BorderFactory.createEmptyBorder());
        s.setOpaque(false);

        Button_back = new JButton("BACK");
        Button_back.setBackground(null);
        Button_back.setFont(new Font("Georgia", Font.BOLD, 16));
        Button_back.setPreferredSize(new Dimension(120, 40));
        Button_back.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        Button_back.setFocusPainted(false);
        Button_back.setForeground(Color.BLACK);
        Button_back.addActionListener(e -> {
            new StudentManagementSystemUI(); 
            dispose(); 
        });

        
        JPanel fPanel = new JPanel();
        fPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        fPanel.add(Button_back);
        fPanel.setOpaque(false);

        bgPanel.add(hPanel, BorderLayout.NORTH);
        bgPanel.add(s, BorderLayout.CENTER);
        bgPanel.add(fPanel, BorderLayout.SOUTH);
        setContentPane(bgPanel);
        setVisible(true);

        display();
    }

    private void display() {
        String txt = "Upcoming Deadlines:\n";
        String s = DR.checkUpcoming_due_tasks();
        Text.setText(txt + s);
    }
}

