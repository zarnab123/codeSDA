package UserInterface;

import javax.swing.*;
import java.awt.*;
import BusinessLogic.ExamTimetable;

public class ExamTimetableUI extends JFrame 
{
    private JTextField Field_to_Search;
    private JButton Button_Search;
    private JLabel Label1;
    private JButton Button_back;

    public ExamTimetableUI() 
    {
        setTitle("Check Exam Timetable");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel bgPanel = new JPanel() 
        {
            private Image bg_image = new ImageIcon("C:\\Users\\user\\OneDrive\\Desktop\\bg 1.jpg").getImage();
            @Override
            protected void paintComponent(Graphics g) 
            {
                super.paintComponent(g);
                g.drawImage(bg_image, 0, 0, getWidth(), getHeight(), this);
            }
        };
        bgPanel.setLayout(new BorderLayout());

        JPanel h_Panel = new JPanel();
        h_Panel.setLayout(new BorderLayout());
        h_Panel.setOpaque(false);

        JLabel h_Label = new JLabel("Exam Timetable Viewer");
        h_Label.setForeground(Color.WHITE);
        h_Label.setHorizontalAlignment(SwingConstants.CENTER);
        h_Label.setFont(new Font("Georgia", Font.BOLD, 24));

        JPanel h_Box = new JPanel();
        h_Box.setLayout(new BorderLayout());
        h_Box.add(h_Label, BorderLayout.CENTER);
        h_Box.setBackground(new Color(135, 206, 235));
        h_Box.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        h_Panel.add(h_Box, BorderLayout.NORTH);

        JPanel s_Panel = new JPanel();
        s_Panel.setLayout(new FlowLayout());
        s_Panel.setOpaque(false);

        Field_to_Search = new JTextField(20);
        Button_Search = new JButton("View Timetable");
        Label1 = new JLabel("Enter student name and click 'View Timetable'");
        Button_Search.addActionListener(e -> searchExamTimetable());

        s_Panel.add(new JLabel("Enter Student Name:"));
        s_Panel.add(Field_to_Search);
        s_Panel.add(Button_Search);
        s_Panel.add(Label1);

        
        Button_back = new JButton("Back");
        Button_back.setBackground(null);
        Button_back.setFont(new Font("Georgia", Font.BOLD, 16));
        Button_back.setPreferredSize(new Dimension(150, 40));
        Button_back.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        Button_back.setFocusPainted(false);
        Button_back.setForeground(Color.BLACK);
        Button_back.addActionListener(e -> {
            new StudentManagementSystemUI(); 
            dispose(); 
        });

        JPanel f_Panel = new JPanel();
        f_Panel.setLayout(new FlowLayout(FlowLayout.LEFT));
        f_Panel.setOpaque(false);
        f_Panel.add(Button_back);
        
        bgPanel.add(h_Panel, BorderLayout.NORTH);
        bgPanel.add(s_Panel, BorderLayout.CENTER);
        bgPanel.add(f_Panel, BorderLayout.SOUTH);

        setContentPane(bgPanel);
        setVisible(true);
    }

    private void searchExamTimetable() 
    {
        String s_Name = Field_to_Search.getText().trim();
        if (!s_Name.isEmpty()) 
        {
            ExamTimetable time_table = new ExamTimetable();
            String s = time_table.getTimetable(s_Name);
            Label1.setText(s);
        } 
        else 
        {
            Label1.setText("Please enter a valid name.");
        }
    }
}
