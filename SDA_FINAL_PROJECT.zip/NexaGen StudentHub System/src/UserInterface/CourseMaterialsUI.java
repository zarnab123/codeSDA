package UserInterface;

import javax.swing.*;
import java.awt.*;
import BusinessLogic.CourseMaterials;

public class CourseMaterialsUI extends JFrame 
{
    private JTextField course_Name_Field;
    private JButton Button_search;
    private JLabel Label1;
    private JButton Button_Back;

    public CourseMaterialsUI() 
    {
        setTitle("Access Course Materials");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel bgPanel = new JPanel() 
        {
            private Image bgImage = new ImageIcon("C:\\Users\\user\\OneDrive\\Desktop\\bg 1.jpg").getImage();
            @Override
            protected void paintComponent(Graphics g) 
            {
                super.paintComponent(g);
                g.drawImage(bgImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        bgPanel.setLayout(new BorderLayout());

        JPanel hPanel = new JPanel();
        hPanel.setLayout(new BorderLayout());
        hPanel.setOpaque(false);

        JLabel hLabel = new JLabel("Course Materials Viewer");
        hLabel.setForeground(Color.WHITE);
        hLabel.setHorizontalAlignment(SwingConstants.CENTER);
        hLabel.setFont(new Font("Georgia", Font.BOLD, 24));

        JPanel hBox = new JPanel();
        hBox.setLayout(new BorderLayout());
        hBox.add(hLabel, BorderLayout.CENTER);
        hBox.setBackground(new Color(135, 206, 235));
        hBox.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        hPanel.add(hBox, BorderLayout.NORTH);

        JPanel sPanel = new JPanel();
        sPanel.setLayout(new FlowLayout());
        sPanel.setOpaque(false);

        course_Name_Field = new JTextField(20);
        Button_search = new JButton("Get Materials");
        Label1 = new JLabel("Enter course name to get materials");
        Button_search.addActionListener(e -> searchCourseMaterials());

        sPanel.add(new JLabel("Course Name:"));
        sPanel.add(course_Name_Field);
        sPanel.add(Button_search);
        sPanel.add(Label1);

        Button_Back = new JButton("Back");
        Button_Back.setFont(new Font("Georgia", Font.BOLD, 16));
        Button_Back.setPreferredSize(new Dimension(150, 40));
        Button_Back.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        Button_Back.setFocusPainted(false);
        Button_Back.setForeground(Color.BLACK);
        Button_Back.addActionListener(e -> {
            new StudentManagementSystemUI(); 
            dispose(); 
        });
        
        JPanel fPanel = new JPanel();
        fPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        fPanel.setOpaque(false);
        fPanel.add(Button_Back);


        bgPanel.add(hPanel, BorderLayout.NORTH);
        bgPanel.add(sPanel, BorderLayout.CENTER);
        bgPanel.add(fPanel, BorderLayout.SOUTH);
        setContentPane(bgPanel);
        setVisible(true);
    }

    private void searchCourseMaterials() 
    {
        String c_Name = course_Name_Field.getText().trim();
        if (!c_Name.isEmpty()) 
        {
            CourseMaterials c_Materials = new CourseMaterials();
            String s = c_Materials.getCourseMaterials(c_Name);
            Label1.setText("<html>" + s.replace("\n", "<br>") + "</html>");
        } 
        else 
        {
            Label1.setText("Please enter a valid course name.");
        }
    }
}
