import javax.swing.SwingUtilities;
import UserInterface.StudentManagementSystemUI;

public class Main 
{
    public Main() {}
    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(new Runnable() 
        {
            @Override
            public void run() 
            {
                new StudentManagementSystemUI();
            }
        });
    }
}
