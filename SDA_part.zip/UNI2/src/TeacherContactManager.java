import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class TeacherContactManager {
    public void showTeacherContactScreen() {
        JFrame teacherContactFrame = new JFrame("Teacher Contacts");
        teacherContactFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        teacherContactFrame.setSize(500, 400);
        teacherContactFrame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        // Labels and fields for teacher data
        JLabel nameLabel = new JLabel("Teacher's Name:");
        JTextField nameField = new JTextField(20);
        JLabel roomLabel = new JLabel("Room Number:");
        JTextField roomField = new JTextField(20);
        JLabel emailLabel = new JLabel("Email:");
        JTextField emailField = new JTextField(20);
        JLabel codeLabel = new JLabel("Classroom Code:");
        JTextField codeField = new JTextField(20);

        JButton submitButton = new JButton("Add Teacher");
        JButton displayButton = new JButton("Display Teachers");

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(nameLabel, gbc);
        gbc.gridx = 1;
        panel.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(roomLabel, gbc);
        gbc.gridx = 1;
        panel.add(roomField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(emailLabel, gbc);
        gbc.gridx = 1;
        panel.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(codeLabel, gbc);
        gbc.gridx = 1;
        panel.add(codeField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(submitButton, gbc);

        gbc.gridx = 1;
        panel.add(displayButton, gbc);

        teacherContactFrame.add(panel);
        teacherContactFrame.setVisible(true);

        // Add Teacher Button Action
        submitButton.addActionListener(e -> {
            String name = nameField.getText();
            String room = roomField.getText();
            String email = emailField.getText();
            String code = codeField.getText();

            if (name.isEmpty() || room.isEmpty() || email.isEmpty() || code.isEmpty()) {
                JOptionPane.showMessageDialog(teacherContactFrame, "All fields are required!");
            } else {
                addTeacher(name, room, email, code);
                JOptionPane.showMessageDialog(teacherContactFrame, "Teacher added successfully!");
                nameField.setText("");
                roomField.setText("");
                emailField.setText("");
                codeField.setText("");
            }
        });

        // Display Teachers Button Action
        displayButton.addActionListener(e -> {
            String teachers = getAllTeachers();
            JOptionPane.showMessageDialog(teacherContactFrame, teachers);
        });
    }

    private void addTeacher(String name, String room, String email, String code) {
        String query = "INSERT INTO teachers (name, room, email, code) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, name);
            pstmt.setString(2, room);
            pstmt.setString(3, email);
            pstmt.setString(4, code);
            pstmt.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    private String getAllTeachers() {
        StringBuilder result = new StringBuilder("Teachers:\n");
        String query = "SELECT * FROM teachers";
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            while (rs.next()) {
                result.append("Name: ").append(rs.getString("name"))
                        .append(", Room: ").append(rs.getString("room"))
                        .append(", Email: ").append(rs.getString("email"))
                        .append(", Code: ").append(rs.getString("code"))
                        .append("\n");
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return result.toString();
    }
}
