import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.net.URI;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DeadlineManager {

    public void showDeadlineScreen(String username) {
        String query = "SELECT deadline_link FROM deadlines WHERE username = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, username);  // Set the username in the query

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String deadlineLink = resultSet.getString("deadline_link");

                // Open the link in the browser
                try {
                    Desktop desktop = Desktop.getDesktop();
                    URI uri = new URI(deadlineLink);
                    desktop.browse(uri); // Opens the link in the default browser
                } catch (IOException | java.net.URISyntaxException ex) {
                    ex.printStackTrace(); // Handle any exceptions that occur
                }
            } else {
                System.out.println("No deadlines found for username: " + username);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
