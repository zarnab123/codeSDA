import java.sql.SQLException;

public class Main {
 /*public static void main(String[] args) {
        // Launch the application by initializing the User Interface

    }
*/
    public static void main(String[] args) throws SQLException {

        DatabaseConnection.getConnection();
       LoginApp.showLoginScreen();
     /*   new UserInterface();*/
    }
}
