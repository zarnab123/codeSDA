import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class UserInterface {
    private JFrame frame;
    private JButton btnViewSchedule, btnViewDeadlines, btnTeacherContacts, btnRegistrationStatus;
    private BusinessLogic logic;

    public UserInterface() {
        logic = new BusinessLogic(); // Business logic instance
        initializeUI();
    }

    private void initializeUI() {
        // Frame setup
        frame = new JFrame("NexaGen - Student Hub");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(450, 400);
        frame.setLayout(new BorderLayout());

        // Header
        JLabel header = new JLabel("Welcome to NexaGen", SwingConstants.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 24));
        header.setForeground(Color.WHITE);
        header.setOpaque(true);
        header.setBackground(new Color(30, 144, 255)); // DodgerBlue background
        header.setPreferredSize(new Dimension(450, 60));

        // Panel for buttons
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(4, 1, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        buttonPanel.setBackground(Color.WHITE);

        // Buttons
        btnViewSchedule = createButton("View Class Schedule");
        btnViewDeadlines = createButton("View Upcoming Deadlines");
        btnTeacherContacts = createButton("Teacher Contact Info");
        btnRegistrationStatus = createButton("View Registration Status");

        // Add buttons to panel
        buttonPanel.add(btnViewSchedule);
        buttonPanel.add(btnViewDeadlines);
        buttonPanel.add(btnTeacherContacts);
        buttonPanel.add(btnRegistrationStatus);

        // Add action listeners
        btnViewSchedule.addActionListener(e -> showSchedule());
        btnViewDeadlines.addActionListener(e -> showDeadlines());
        btnTeacherContacts.addActionListener(e -> showTeacherContacts());
        btnRegistrationStatus.addActionListener(e -> showRegistrationStatus());

        // Add components to frame
        frame.add(header, BorderLayout.NORTH);
        frame.add(buttonPanel, BorderLayout.CENTER);

        // Display the frame
        frame.setVisible(true);
    }

    private JButton createButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.PLAIN, 18));
        button.setBackground(new Color(135, 206, 250)); // LightSkyBlue background
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createLineBorder(new Color(30, 144, 255))); // DodgerBlue border
        return button;
    }

    private void showSchedule() {
        String username = Session.getLoggedInUser();

        if (username == null) {
            JOptionPane.showMessageDialog(frame, "You need to log in first.", "Login Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String schedule = logic.getClassSchedule();

        if (schedule.startsWith("No schedule found")) {
            JOptionPane.showMessageDialog(frame, schedule, "No Schedule", JOptionPane.WARNING_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(frame, "Your schedule has been opened in the browser.", "Schedule Found", JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void showDeadlines() {
        // Get the username of the logged-in user
        String username = Session.getLoggedInUser();

        if (username == null) {
            JOptionPane.showMessageDialog(frame, "You need to log in first.", "Login Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Show the deadlines screen via BusinessLogic, passing the username
        logic.showDeadlineScreen(username);
    }


    private void showTeacherContacts() {
        // Show the teacher contact screen via BusinessLogic
        logic.showTeacherContactScreen();
    }

    private void showRegistrationStatus() {
        String username = Session.getLoggedInUser();

        if (username == null) {
            JOptionPane.showMessageDialog(frame, "You need to log in first.", "Login Required", JOptionPane.WARNING_MESSAGE);
            return;
        }

        logic.showRegistrationLink(username);  // Call the method from BusinessLogic to show the registration link
    }


    public static void main(String[] args) {
        new UserInterface(); // Start the application
    }
}
