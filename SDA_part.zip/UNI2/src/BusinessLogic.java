public class BusinessLogic {
    private ClassScheduleManager scheduleManager;
    private DeadlineManager deadlineManager;
    private TeacherContactManager contactManager;
    private RegistrationManager registrationManager;

    public BusinessLogic() {
        scheduleManager = new ClassScheduleManager();  // Initialize ClassScheduleManager
        deadlineManager = new DeadlineManager();
        contactManager = new TeacherContactManager();
        registrationManager = new RegistrationManager();
    }

    // Method to get the class schedule for a student
    public String getClassSchedule() {
        return scheduleManager.getClassSchedule(); // Call the method from ClassScheduleManager
    }

    // Method to show the registration link for a student
    public void showRegistrationLink(String username) {
        registrationManager.showRegistrationLink(username);
    }
    public void showTeacherContactScreen() {
        contactManager.showTeacherContactScreen();
    }

    // Method to show the deadline screen for a specific user
    public void showDeadlineScreen(String username) {
        deadlineManager.showDeadlineScreen(username); // Pass username to DeadlineManager
    }
}
