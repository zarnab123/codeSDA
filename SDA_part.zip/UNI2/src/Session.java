public class Session {
    private static String loggedInUsername;  // Static variable to store logged-in username

    // Set the logged-in username
    public static void setLoggedInUser(String username) {
        loggedInUsername = username;
    }

    // Get the logged-in username
    public static String getLoggedInUser() {
        return loggedInUsername;
    }
}
