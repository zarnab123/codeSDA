import javax.swing.*;
import java.awt.*;
import java.net.URI;
import java.sql.*;

public class RegistrationManager {

    // Method to show registration link based on username
    public void showRegistrationLink(String username) {
        String query = "SELECT registration_link FROM registration WHERE username = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, username);  // Set the username in the query

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                String registrationLink = resultSet.getString("registration_link");

                // Open the registration link in the default browser
                try {
                    Desktop desktop = Desktop.getDesktop();
                    URI uri = new URI(registrationLink);
                    desktop.browse(uri); // Open the link in the default browser
                } catch (Exception e) {
                    e.printStackTrace(); // Handle exceptions when opening the URL
                }
            } else {
                JOptionPane.showMessageDialog(null,
                        "No registration link found for username: " + username,
                        "No Registration Link",
                        JOptionPane.WARNING_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
