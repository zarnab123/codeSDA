import java.awt.*;
import java.io.IOException;
import java.net.URI;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ClassScheduleManager {

    private DatabaseConnection dbManager;  // Instance of DatabaseManager

    public ClassScheduleManager() {
        dbManager = new DatabaseConnection();  // Initialize DatabaseManager
    }

    public String getClassSchedule() {
        // Get the logged-in username from Session
        String username = Session.getLoggedInUser();

        if (username == null) {
            System.out.println("No user is logged in.");
            return "Error: No user is logged in.";
        }

        // Fetch schedule link from the database
        String scheduleLink = getScheduleFromDatabase(username);

        if (scheduleLink == null || scheduleLink.equals("No schedule found.")) {
            System.out.println("No schedule found for username: " + username);
            return "No schedule found for user " + username;
        } else {
            System.out.println("Schedule link for user " + username + ": " + scheduleLink);
            openScheduleInBrowser(scheduleLink);  // Open in browser
        }
        return scheduleLink;
    }

    private String getScheduleFromDatabase(String username) {
        String scheduleLink = null;
        String query = "SELECT schedule_link FROM student_schedules WHERE username = ?";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, username);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                scheduleLink = resultSet.getString("schedule_link");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return (scheduleLink == null) ? "No schedule found." : scheduleLink;
    }


    private void openScheduleInBrowser(String scheduleLink) {
        try {
            if (Desktop.isDesktopSupported()) {
                Desktop desktop = Desktop.getDesktop();
                URI uri = new URI(scheduleLink);
                desktop.browse(uri);
            }
        } catch (IOException | java.net.URISyntaxException e) {
            e.printStackTrace();
        }
    }
}
