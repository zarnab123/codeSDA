import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://127.0.0.1:3306/nexagen_db?useSSL=false";
    private static final String USER = "root";
    private static final String PASSWORD = "sql@aish2128";

    public static Connection getConnection() throws SQLException {
        // Ensure a new connection is created for each call
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

}

