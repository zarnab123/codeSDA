import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class LoginApp {

    private static boolean isUserLoggedIn = false; // Track if user is logged in

    public static void showLoginScreen() {
        JFrame frame = new JFrame("Login Application");
        frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Create background panel and form panel
        BackgroundPanel backgroundPanel = new BackgroundPanel("src/background1.jpg");

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(new Color(255, 255, 255, 200));  // Semi-transparent background
        formPanel.setOpaque(false);

        GridBagConstraints formGbc = new GridBagConstraints();
        formGbc.insets = new Insets(5, 5, 5, 5);
        formGbc.fill = GridBagConstraints.HORIZONTAL;

        Font font = new Font("Arial", Font.PLAIN, 14);

        // Username label and text field
        JLabel userLabel = new JLabel("Username:");
        userLabel.setFont(font);
        JTextField userText = new JTextField(15);
        userText.setFont(font);

        // Password label and text field
        JLabel passLabel = new JLabel("Password:");
        passLabel.setFont(font);
        JPasswordField passText = new JPasswordField(15);
        passText.setFont(font);

        // Create login and sign-up buttons
        JButton loginButton = new JButton("Login");
        loginButton.setFont(new Font("Arial", Font.BOLD, 14));
        loginButton.setBackground(new Color(0, 123, 255));
        loginButton.setForeground(Color.WHITE);

        JButton signUpButton = new JButton("Sign Up");
        signUpButton.setFont(new Font("Arial", Font.PLAIN, 14));
        signUpButton.setBackground(new Color(40, 167, 69));
        signUpButton.setForeground(Color.WHITE);

        // Add components to the form panel
        formGbc.gridx = 0;
        formGbc.gridy = 0;
        formPanel.add(userLabel, formGbc);

        formGbc.gridx = 1;
        formPanel.add(userText, formGbc);

        formGbc.gridx = 0;
        formGbc.gridy = 1;
        formPanel.add(passLabel, formGbc);

        formGbc.gridx = 1;
        formPanel.add(passText, formGbc);

        formGbc.gridx = 0;
        formGbc.gridy = 2;
        formGbc.gridwidth = 2;
        formPanel.add(loginButton, formGbc);

        formGbc.gridy = 3;
        formPanel.add(signUpButton, formGbc);

        // Add form panel to the background panel
        backgroundPanel.add(formPanel, BorderLayout.CENTER);
        frame.add(backgroundPanel);
        frame.setVisible(true);

     /*   // Action listeners for login and sign-up buttons
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText();
                String password = new String(passText.getPassword());

                if (validateUser(username, password)) {
                    isUserLoggedIn = true;
                    JOptionPane.showMessageDialog(frame, "Login successful!");
                    frame.dispose();
                    // After login, show User Interface
                    new UserInterface(); // Open User Interface
                } else {
                    JOptionPane.showMessageDialog(frame, "Invalid credentials, please try again.");
                }
            }
        });*/

        // Action listeners for login and sign-up buttons
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText();
                String password = new String(passText.getPassword());

                if (validateUser(username, password)) {
                    // Set the logged-in user in the session
                    Session.setLoggedInUser(username);  // Store the username globally in Session

                    // Set the user as logged in
                    isUserLoggedIn = true;

                    // Show success message
                    JOptionPane.showMessageDialog(frame, "Login successful!");

                    // Close the login screen and open the User Interface
                    frame.dispose();
                    new UserInterface();  // Open User Interface (you can pass the username if needed)
                } else {
                    // Show error message for invalid credentials
                    JOptionPane.showMessageDialog(frame, "Invalid credentials, please try again.");
                }
            }
        });






        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showSignUpScreen();
            }
        });
    }

    private static boolean validateUser(String username, String password) {
        String query = "SELECT * FROM users WHERE username = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setString(1, username);

            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                // Compare the hashed password from the database with the entered password
                String storedPasswordHash = resultSet.getString("password_hash");
                if (storedPasswordHash.equals(hashPassword(password))) {
                    return true;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
        }
        return false;
    }

    private static String hashPassword(String password) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] hashedBytes = digest.digest(password.getBytes());
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashedBytes) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    private static void showSignUpScreen() {
        JFrame frame = new JFrame("Sign Up");
        frame.setSize(400, 300);
        frame.setLocationRelativeTo(null);

        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel userLabel = new JLabel("Username:");
        JTextField userText = new JTextField(20);

        JLabel passLabel = new JLabel("Password:");
        JPasswordField passText = new JPasswordField(20);

        JButton signUpButton = new JButton("Sign Up");

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(userLabel, gbc);
        gbc.gridx = 1;
        panel.add(userText, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(passLabel, gbc);
        gbc.gridx = 1;
        panel.add(passText, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        panel.add(signUpButton, gbc);

        frame.add(panel);
        frame.setVisible(true);

        signUpButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = userText.getText();
                String password = new String(passText.getPassword());

                if (registerUser(username, password)) {
                    JOptionPane.showMessageDialog(frame, "Sign up successful! Please log in.");
                    frame.dispose();
                    showLoginScreen();
                } else {
                    JOptionPane.showMessageDialog(frame, "Sign up failed. Try again.");
                }
            }
        });
    }

    private static boolean registerUser(String username, String password) {
        String query = "INSERT INTO users (username, password_hash) VALUES (?, ?)";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            // Hash the password before saving
            String hashedPassword = hashPassword(password);
            if (hashedPassword == null) {
                JOptionPane.showMessageDialog(null, "Password hashing failed.");
                return false;
            }

            preparedStatement.setString(1, username);
            preparedStatement.setString(2, hashedPassword);

            // Log the query and parameters for debugging
            System.out.println("Executing query: " + query);
            System.out.println("Username: " + username);
            System.out.println("Hashed Password: " + hashedPassword);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                return true;
            } else {
                JOptionPane.showMessageDialog(null, "No rows were inserted.");
                return false;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database error: " + e.getMessage());
            return false;
        }
    }

/*
public static void main(String[] args) {
        showLoginScreen(); // Start the login screen
    }
*/

}

